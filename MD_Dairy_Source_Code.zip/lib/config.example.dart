// Copy this file to config.dart and fill in your project values.
// Never put a Supabase service-role key here. Use only the anon/publishable key.
const supabaseUrl = 'https://YOUR_PROJECT.supabase.co';
const supabaseAnonKey = 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY';
