import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';

final supabase = Supabase.instance.client;

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int farmerCount = 0;
  int entryCount = 0;
  bool loading = true;
  String dairyName = 'MD Dairy';

  Future<void> load() async {
    try {
      final dairy = await supabase.from('dairies').select('name').maybeSingle();
      final farmers = await supabase.from('farmers').select('id');
      final entries = await supabase.from('milk_entries').select('id');
      if (!mounted) return;
      setState(() {
        dairyName = dairy?['name'] ?? 'MD Dairy';
        farmerCount = (farmers as List).length;
        entryCount = (entries as List).length;
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void initState() { super.initState(); load(); }

  Future<void> addFarmer() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Add farmer / शेतकरी जोडा'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Name / नाव')),
        const SizedBox(height: 10),
        TextField(controller: phone, keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Phone / मोबाईल')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save')),
      ],
    ));
    if (ok == true && name.text.trim().isNotEmpty) {
      await supabase.from('farmers').insert({'name': name.text.trim(), 'phone': phone.text.trim()});
      await load();
    }
  }

  Future<void> addMilkEntry() async {
    final farmers = await supabase.from('farmers').select('id,name').order('name');
    if (!mounted) return;
    if ((farmers as List).isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add a farmer first / आधी शेतकरी जोडा')));
      return;
    }
    String farmerId = farmers.first['id'].toString();
    String shift = 'Morning';
    final litres = TextEditingController(text: '10');
    final fat = TextEditingController(text: '4.0');
    final rate = TextEditingController(text: '35');
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
      title: const Text('Milk collection / दूध संकलन'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(
          value: farmerId,
          items: farmers.map<DropdownMenuItem<String>>((f) => DropdownMenuItem(
            value: f['id'].toString(), child: Text(f['name'].toString()))).toList(),
          onChanged: (v) => setDialog(() => farmerId = v!),
          decoration: const InputDecoration(labelText: 'Farmer / शेतकरी'),
        ),
        DropdownButtonFormField<String>(
          value: shift, items: const [
            DropdownMenuItem(value: 'Morning', child: Text('Morning / सकाळ')),
            DropdownMenuItem(value: 'Evening', child: Text('Evening / संध्याकाळ')),
          ], onChanged: (v) => setDialog(() => shift = v!),
          decoration: const InputDecoration(labelText: 'Shift / सत्र'),
        ),
        TextField(controller: litres, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Litres / लिटर')),
        TextField(controller: fat, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fat %')),
        TextField(controller: rate, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Rate per litre / दर')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save entry')),
      ],
    )));
    if (ok == true) {
      final l = double.tryParse(litres.text) ?? 0;
      final r = double.tryParse(rate.text) ?? 0;
      final f = double.tryParse(fat.text) ?? 0;
      if (l <= 0 || r < 0) return;
      await supabase.from('milk_entries').insert({
        'farmer_id': farmerId, 'shift': shift, 'litres': l,
        'fat': f, 'rate_per_litre': r, 'amount': l * r,
        'collected_on': DateFormat('yyyy-MM-dd').format(DateTime.now()),
      });
      await load();
    }
  }

  Future<void> showFarmers() async {
    final rows = await supabase.from('farmers').select('name,phone,created_at').order('name');
    if (!mounted) return;
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => ListView(
      padding: const EdgeInsets.all(16), children: [
        Text('Farmers / शेतकरी', style: Theme.of(context).textTheme.titleLarge),
        for (final f in rows) ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(f['name'] ?? ''),
          subtitle: Text(f['phone'] ?? ''),
        ),
      ],
    ));
  }

  Future<void> showEntries() async {
    final rows = await supabase.from('milk_entries')
      .select('litres,fat,rate_per_litre,amount,shift,collected_on,farmers(name)')
      .order('created_at', ascending: false).limit(100);
    if (!mounted) return;
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => ListView(
      padding: const EdgeInsets.all(16), children: [
        Text('Milk entries / दूध नोंदी', style: Theme.of(context).textTheme.titleLarge),
        for (final e in rows) ListTile(
          title: Text('${e['farmers']?['name'] ?? 'Farmer'} • ${e['shift']}'),
          subtitle: Text('${e['collected_on']} • ${e['litres']} L • Fat ${e['fat']}%'),
          trailing: Text('₹${(e['amount'] as num).toStringAsFixed(2)}'),
        ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(dairyName), actions: [
      IconButton(tooltip: 'Logout', onPressed: () => supabase.auth.signOut(), icon: const Icon(Icons.logout)),
    ]),
    body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Text('Welcome / स्वागत आहे', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _stat('Farmers / शेतकरी', '$farmerCount', Icons.people)),
          const SizedBox(width: 12),
          Expanded(child: _stat('Milk entries / नोंदी', '$entryCount', Icons.water_drop)),
        ]),
        const SizedBox(height: 18),
        _action(Icons.person_add, 'Add farmer / शेतकरी जोडा', addFarmer),
        _action(Icons.add_circle, 'Milk collection / दूध नोंदवा', addMilkEntry),
        _action(Icons.people, 'View farmers / शेतकरी यादी', showFarmers),
        _action(Icons.receipt_long, 'View milk entries / दूध नोंदी', showEntries),
        const SizedBox(height: 18),
        Card(child: ListTile(
          leading: const Icon(Icons.workspace_premium, color: Color(0xFFD49B24)),
          title: const Text('MD Dairy Premium'),
          subtitle: const Text('₹999 / year • Payment activation to be connected'),
          trailing: const Icon(Icons.lock_outline),
        )),
      ]),
    ),
  );

  Widget _stat(String label, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      Icon(icon, size: 28, color: Theme.of(context).colorScheme.primary),
      const SizedBox(height: 8), Text(value, style: Theme.of(context).textTheme.headlineMedium),
      Text(label, textAlign: TextAlign.center),
    ])),
  );

  Widget _action(IconData icon, String title, VoidCallback onTap) => Card(
    child: ListTile(leading: Icon(icon), title: Text(title),
      trailing: const Icon(Icons.chevron_right), onTap: onTap),
  );
}
