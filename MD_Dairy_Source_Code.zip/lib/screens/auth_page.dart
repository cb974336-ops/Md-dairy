import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final dairyName = TextEditingController();
  bool isRegister = true;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      final auth = Supabase.instance.client.auth;
      if (isRegister) {
        if (dairyName.text.trim().isEmpty) throw Exception('Enter dairy name / डेअरीचे नाव टाका');
        await auth.signUp(
          email: email.text.trim(),
          password: password.text,
          data: {'dairy_name': dairyName.text.trim()},
        );
      } else {
        await auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose(); password.dispose(); dairyName.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: ListView(
          padding: const EdgeInsets.all(24),
          shrinkWrap: true,
          children: [
            const Icon(Icons.water_drop, size: 58, color: Color(0xFF147D52)),
            const SizedBox(height: 8),
            Text('MD Dairy', textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            const Text('दूध संकलन आणि डेअरी व्यवस्थापन', textAlign: TextAlign.center),
            const SizedBox(height: 28),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Register / नोंदणी')),
                ButtonSegment(value: false, label: Text('Login / लॉगिन')),
              ],
              selected: {isRegister},
              onSelectionChanged: (v) => setState(() { isRegister = v.first; error = null; }),
            ),
            const SizedBox(height: 18),
            if (isRegister) ...[
              TextField(controller: dairyName, decoration: const InputDecoration(labelText: 'Dairy name / डेअरीचे नाव')),
              const SizedBox(height: 12),
            ],
            TextField(controller: email, keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email')),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText: true,
              decoration: const InputDecoration(labelText: 'Password (min 6 characters)')),
            if (error != null) Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(error!, style: const TextStyle(color: Colors.red)),
            ),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: busy ? null : submit,
              child: Text(busy ? 'Please wait…' : (isRegister ? 'Create account' : 'Login')),
            ),
            const SizedBox(height: 12),
            const Text('प्रत्येक डेअरीचा डेटा स्वतंत्र आणि सुरक्षित ठेवला जातो.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
          ],
        ),
      ),
    ),
  );
}
