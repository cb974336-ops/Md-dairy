-- Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'owner' check (role in ('owner','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.dairies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.farmers (
  id uuid primary key default gen_random_uuid(),
  dairy_id uuid not null references public.dairies(id) on delete cascade,
  name text not null,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.milk_entries (
  id uuid primary key default gen_random_uuid(),
  dairy_id uuid not null references public.dairies(id) on delete cascade,
  farmer_id uuid not null references public.farmers(id) on delete cascade,
  shift text not null check (shift in ('Morning','Evening')),
  litres numeric(10,2) not null check (litres > 0),
  fat numeric(5,2) not null default 0,
  rate_per_litre numeric(10,2) not null default 0,
  amount numeric(12,2) not null default 0,
  collected_on date not null default current_date,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  dairy_id uuid not null unique references public.dairies(id) on delete cascade,
  plan_name text not null default 'MD Dairy Premium',
  amount_inr integer not null default 999,
  duration_days integer not null default 365,
  status text not null default 'inactive' check (status in ('inactive','active','expired','cancelled')),
  starts_at timestamptz,
  ends_at timestamptz,
  provider text,
  provider_payment_id text,
  created_at timestamptz not null default now()
);

create index if not exists farmers_dairy_id_idx on public.farmers(dairy_id);
create index if not exists milk_entries_dairy_date_idx on public.milk_entries(dairy_id, collected_on desc);


create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.current_dairy_id()
returns uuid language sql stable security definer set search_path = public
as $$
  select id from public.dairies where owner_id = auth.uid() limit 1;
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare new_dairy_id uuid;
begin
  insert into public.profiles(id, email) values (new.id, new.email)
  on conflict (id) do nothing;

  insert into public.dairies(owner_id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'dairy_name', 'My Dairy'))
  on conflict (owner_id) do nothing
  returning id into new_dairy_id;

  if new_dairy_id is not null then
    insert into public.subscriptions(dairy_id) values (new_dairy_id)
    on conflict (dairy_id) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_md_dairy on auth.users;
create trigger on_auth_user_created_md_dairy
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.dairies enable row level security;
alter table public.farmers enable row level security;
alter table public.milk_entries enable row level security;
alter table public.subscriptions enable row level security;

-- Profile: users may read/update their own profile. Admin visibility is handled by admin page via policy.
create policy "profile own read" on public.profiles for select
using (id = auth.uid() or public.is_admin());
create policy "profile own update" on public.profiles for update
using (id = auth.uid()) with check (id = auth.uid());

create policy "dairy owner read" on public.dairies for select
using (owner_id = auth.uid() or public.is_admin());
create policy "dairy owner update" on public.dairies for update
using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "farmers tenant access" on public.farmers for all
using (dairy_id = public.current_dairy_id() or public.is_admin())
with check (dairy_id = public.current_dairy_id() or public.is_admin());

create policy "milk tenant access" on public.milk_entries for all
using (dairy_id = public.current_dairy_id() or public.is_admin())
with check (
  (dairy_id = public.current_dairy_id() and exists (
    select 1 from public.farmers f where f.id = farmer_id and f.dairy_id = public.current_dairy_id()
  )) or public.is_admin()
);

create policy "subscription owner read" on public.subscriptions for select
using (dairy_id = public.current_dairy_id() or public.is_admin());

-- Subscription rows are deliberately not writable by normal clients.
-- Only trusted server-side payment verification/admin tooling should activate them.
