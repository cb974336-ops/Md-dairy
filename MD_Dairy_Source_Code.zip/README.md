# MD Dairy MVP

Cross-platform Flutter starter for Android + iPhone, with a separate web admin starter and Supabase backend.

## Included in this MVP
- Email/password sign-up and sign-in
- Each registered owner gets a separate dairy workspace
- Farmer register/list
- Morning/evening milk collection entries
- Basic amount calculation (`litres × rate_per_litre`)
- Row-level security (RLS) so a dairy can only access its own records
- Basic admin web page for accounts and subscriptions (requires a trusted admin role)

## Important
This is a development starter, not a production-ready billing system. The ₹999/year subscription is represented in the database, but payment activation must only happen after server-side Razorpay verification. Never put Razorpay secret keys or Supabase service-role keys in the mobile app or browser.

## Requirements
- Flutter stable (Android/iOS; macOS required to build iOS)
- Supabase project
- Supabase CLI (optional, for migrations)

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Authentication settings, enable Email provider.
4. Copy `lib/config.example.dart` to `lib/config.dart` and enter your Supabase URL and anon/publishable key.
5. From this folder run:
   ```bash
   flutter create . --platforms=android,ios
   flutter pub get
   flutter run
   ```
6. For iOS, open `ios/Runner.xcworkspace` in Xcode and configure signing.
7. Admin web:
   - Serve `admin/` using any static web server.
   - Copy `admin/config.example.js` to `admin/config.js` and set Supabase URL + anon key.
   - Promote your own account to `admin` in Supabase SQL Editor:
     `update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';`

## MVP flow
- Sign up creates a profile and a dairy workspace.
- The owner can add farmers and milk entries.
- The owner sees only records belonging to their dairy.
- Admin web lists dairies and subscriptions only for users with the `admin` role.

## Production checklist
- Add phone OTP / password reset and account recovery.
- Add server-side Razorpay order creation + webhook/signature verification (Supabase Edge Function).
- Activate subscriptions only after verified payment.
- Add subscription expiry enforcement in database policies / Edge Functions.
- Add audit logs, backups, monitoring, privacy policy, terms, and data export/deletion.
- Test calculations, date/time zones, and access controls before launch.

## Suggested subscription
- Plan: MD Dairy Premium
- Price: INR 999
- Duration: 12 months
- Do not claim a payment is successful based only on a client callback.


## Build APK from an Android phone with GitHub Actions
1. Upload this project to a GitHub repository (keep the folder structure).
2. In GitHub repository: Settings → Secrets and variables → Actions → New repository secret.
3. Add `SUPABASE_URL` and `SUPABASE_ANON_KEY` from your Supabase project.
4. Open Actions → `Build MD Dairy Android APK` → Run workflow (or push to `main`).
5. Wait for the workflow to finish, open its run, and download the `md-dairy-android-apk` artifact.
6. Extract the downloaded artifact ZIP to get `app-release.apk`.

If you have not created a Supabase project yet, the workflow can still compile with empty secrets, but the app will not connect or register users until valid Supabase settings are added. Do not add service-role keys or payment secrets to GitHub mobile app code.
