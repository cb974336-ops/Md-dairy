const cfg = window.MD_DAIRY_CONFIG;
if (!cfg || !cfg.url || cfg.url.includes('YOUR_PROJECT')) {
  document.getElementById('message').textContent = 'Set Supabase URL and anon key in config.js first.';
}
const sb = window.supabase.createClient(cfg.url, cfg.anonKey);
const loginPanel = document.getElementById('loginPanel');
const dashboard = document.getElementById('dashboard');
const message = document.getElementById('message');

document.getElementById('login').onclick = async () => {
  message.textContent = '';
  const { error } = await sb.auth.signInWithPassword({
    email: document.getElementById('email').value,
    password: document.getElementById('password').value
  });
  if (error) { message.textContent = error.message; return; }
  await showDashboard();
};
document.getElementById('logout').onclick = async () => { await sb.auth.signOut(); showLogin(); };

async function showLogin() { loginPanel.classList.remove('hidden'); dashboard.classList.add('hidden'); }
async function showDashboard() {
  const { data: userData } = await sb.auth.getUser();
  if (!userData.user) return showLogin();
  const { data: profile, error: profileError } = await sb.from('profiles').select('role').eq('id', userData.user.id).single();
  if (profileError || profile?.role !== 'admin') {
    message.textContent = 'This account is not an admin. Ask the system owner to grant admin role.';
    await sb.auth.signOut(); return showLogin();
  }
  loginPanel.classList.add('hidden'); dashboard.classList.remove('hidden');
  const { data, error } = await sb.from('dairies')
    .select('id,name,owner_id,created_at,subscriptions(status,ends_at,amount_inr)')
    .order('created_at', { ascending: false });
  const target = document.getElementById('accounts');
  if (error) { target.textContent = error.message; return; }
  if (!data.length) { target.textContent = 'No dairy accounts yet.'; return; }
  target.innerHTML = `<table><thead><tr><th>Dairy</th><th>Owner ID</th><th>Created</th><th>Subscription</th></tr></thead><tbody>${
    data.map(d => `<tr><td>${escapeHtml(d.name)}</td><td class="muted">${d.owner_id.slice(0,8)}…</td><td>${new Date(d.created_at).toLocaleDateString()}</td><td><span class="status">${escapeHtml(d.subscriptions?.status || 'inactive')}</span></td></tr>`).join('')
  }</tbody></table>`;
}
function escapeHtml(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
sb.auth.getSession().then(({data}) => data.session ? showDashboard() : showLogin());
