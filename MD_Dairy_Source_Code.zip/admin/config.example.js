// Copy to config.js. Use only the Supabase anon/publishable key here.
window.MD_DAIRY_CONFIG = {
  url: 'https://YOUR_PROJECT.supabase.co',
  anonKey: 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY'
};
